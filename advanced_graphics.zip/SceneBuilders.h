#pragma once
#include "Scene.h"

namespace SceneBuilders
{
	Scene bunch_of_objects();
	Scene billion_triangles_bunnies();
	Scene glass_dragon();
	Scene path_tracing_test();
};

