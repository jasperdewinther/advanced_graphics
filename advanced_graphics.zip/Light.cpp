#include "precomp.h"
#include "Light.h"



Light::Light(float3 position, float3 color) :
	pos(position),
	color(color)
{}